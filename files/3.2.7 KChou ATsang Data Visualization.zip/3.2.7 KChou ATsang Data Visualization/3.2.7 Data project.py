import os.path 
import matplotlib.pyplot as plt
import matplotlib

directory = os.path.dirname(os.path.abspath(__file__))

outputYear=[]
outputIndex=[]

spendingYear = []
spendingAmount = []

def output_scanner():
    # Open the file
    filename = os.path.join(directory, 'Apparel Manufacturing Output.csv')
    
    print (filename)
    

    datafile = open(filename,'r')
    data = datafile.readlines()
    # Go through all the names that year
    for line in data[2:]:
        first_column, second_column,third_column, fourth_column, fifth_column = line.split(',')
        
        outputYear.append(int(first_column))
        outputIndex.append(float(fourth_column))
    #Close that year's file
    datafile.close()
    
def spending_scanner():
     # Open the file
    filename = os.path.join(directory, 'Apparel Manufacturing Spending.csv')
    
    print (filename)
    

    datafile = open(filename,'r')
    data = datafile.readlines()
    # Go through all the names that year
    for line in data:
        item_one, item_two =  line.split(',')
        
        spendingYear.append(int(item_one))
        spendingAmount.append(int(item_two))
              
    #Close that year's file
    datafile.close()
    



output_scanner()
spending_scanner()

fig,ax = plt.subplots(1,2, figsize= (13,6))
ax[0].plot(outputYear, outputIndex,'#FFFFFF')
ax[1].plot(spendingYear, spendingAmount,'#FFFFFF')
fig.patch.set_facecolor('white')
ax[0].set_axis_bgcolor('lightslategray')
ax[1].set_axis_bgcolor('lightslategray')
ax[0].set_title('Indexed Output \n of the Apparel Manufacturing Industry', color= 'black', fontsize= 12)
ax[1].set_title('Average Annual Family Expenditure \n in Apparel', color= 'black', fontsize= 12)
ax[0].set_xlabel('Years')
ax[1].set_xlabel('Years')
ax[0].set_ylabel('Productivity Index from Reference Year 1987')
ax[1].set_ylabel('Dollars (Per Year, Per Household)')
fig.show()